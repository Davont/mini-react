import Vue from "vue";
import App from "./App.vue";
// import Button from "opentiny-vue-charts/core/components/button";
import { Button } from "opentiny-vue-charts/dist/bundle.js";
import "./assets/main.css";

// console.log(Button);
// const MyPlugin = {
//   install(Vue) {
//     Vue.component("Buttons", Buttons);
//   },
// };

Vue.use(Button);
// Vue.component("Buttons", Button);

new Vue({
  render: (h) => h(App),
}).$mount("#app");
