import Vue from "vue";
import App from "./App.vue";
// import Button from "opentiny-vue-charts/core/components/button";
import { Button } from "opentiny-vue-charts/dist/bundle.js";

import "./assets/main.css";

Vue.use(Button);

new Vue({
  render: (h) => h(App),
}).$mount("#app");
