import './assets/main.css'
// import {PgButton} from "opentiny-vue-charts/dist/button/button.esm.js";
// import Button from "opentiny-vue-charts/core/components/button";
import {Button} from "opentiny-vue-charts/dist/bundle.js";

import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App)

app.use(Button);

app.mount('#app')
