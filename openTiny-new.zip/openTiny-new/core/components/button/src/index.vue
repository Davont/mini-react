<template>
  <button
    ref="_ref"
    :class="[
      'pg-button',
      'cursor-pointer',
      'py-2 px-3'
    ]"
  >
  <span>112</span>
    <slot></slot>
  </button>
</template>

