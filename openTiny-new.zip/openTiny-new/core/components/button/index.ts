import Button from './src/index.vue'

const ButtonInstall = {
  install(app:any) {
    app.component('Button', Button)
  }
}

export default ButtonInstall
export { Button }
