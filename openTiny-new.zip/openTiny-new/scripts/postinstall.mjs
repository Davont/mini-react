// 修改package.json module等
function switchVersion(version) {
    const pkg = require('../package.json');
    Object.assign(pkg, moduleMap[version]);
  
    const pkgStr = JSON.stringify(pkg, null, 2);
  
    fs.writeFileSync(path.resolve(__dirname, '../package.json'), pkgStr, 'utf-8');
  }
  
  
  const version =
    process.env.npm_config_vueVersion || (Vue ? Vue.version : '2.7.');
  if (!Vue || typeof version !== 'string') {
    console.warn(
      'Vue is not found. Please run "npm install vue" to install.'
    );
  } else if (version.startsWith('2.7.')) {
    switchVersion(2.7);
  } else if (version.startsWith('2.')) {
    switchVersion(2);
  } else if (version.startsWith('3.')) {
    switchVersion(3);
  } else {
    console.warn(`Vue version v${version} is not suppported.`);
  }