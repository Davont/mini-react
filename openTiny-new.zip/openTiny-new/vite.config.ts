import { defineConfig } from 'vite'
import vue3 from '@vitejs/plugin-vue'
import { createVuePlugin } from 'vite-plugin-vue2';
import * as compiler from '@vue/compiler-sfc'
import {resolve} from 'path'
// import dts from 'vite-plugin-dts'
const isVue2 = process.env.VUE_VERSION === '2';
const vueVersion = process.env.VUE_VERSION || '3';
console.log(process.env.VUE_VERSION);
export default defineConfig({
  plugins: [isVue2
    ? createVuePlugin()
    : vue3({
        compiler: compiler
      })],
  resolve: {
    alias: {
      'vue': isVue2 ? resolve(__dirname, 'node_modules/vue2') : resolve(__dirname, 'node_modules/vue3'),
    }
  },
  build: {
    sourcemap: true,
    lib: {
      entry: {
        [`Button/index`]: `core/Components/Button/index.ts`,
        [`Tag/index`]: `core/Components/Tag/index.ts`,
      },
      formats: ['es', 'cjs'],
    },
    outDir: isVue2 ? 'dist/v2' : 'dist/v3',
    rollupOptions: {
      external: ['vue'],
      output: {
        globals: {
          vue: 'Vue',
        }
      }
    },
  },
})